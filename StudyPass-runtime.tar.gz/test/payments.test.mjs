import {test} from 'node:test';
import assert from 'node:assert/strict';
import {createServer} from 'node:http';
import {once} from 'node:events';
import {randomBytes} from 'node:crypto';
import {paymentConfig,createPaymentService,zecToZatoshis} from '../payments.mjs';
import {createApp} from '../server.mjs';

// Fixtures and stub gateway are test-only. They are never available in the app.
const now=Date.now(),env={ZCASH_NETWORK:'testnet',APP_ORIGIN:'http://127.0.0.1:4180',CIPHERPAY_API_URL:'https://gateway.example',CIPHERPAY_CHECKOUT_ORIGIN:'https://checkout.example',CIPHERPAY_API_KEY:'cpay_test_fixture_only',STUDYPASS_ORDER_KEY:randomBytes(32).toString('hex')};
function invoice(name){return {id:'invoice-fixture',product_name:name,currency:'USD',amount:1,memo_code:'CP-12345678',payment_address:'utest1qqqqqqqqqqqqqqqqqq',price_zatoshis:100000,received_zatoshis:0,status:'pending',created_at:new Date(now).toISOString(),expires_at:new Date(now+1800000).toISOString(),confirmed_at:null,detected_txid:null,refunded_at:null,refund_txid:null,zcash_uri:'zcash:utest1qqqqqqqqqqqqqqqqqq?amount=0.00100000&memo='+Buffer.from('CP-12345678').toString('base64url')};}
function created(i){return {...i,invoice_id:i.id,checkout_url:'https://checkout.example/pay/'+i.id+'#checkout=fixture-token'};}
function fixture(){
  let i,calls=0,down=false;
  const fetchImpl=async(url,options)=>{calls++;assert.equal(options.headers.authorization,'Bearer '+env.CIPHERPAY_API_KEY);if(down)throw Error('upstream secret must never leak');if(options.method==='POST'){const b=JSON.parse(options.body);assert.equal(b.amount,1);assert.equal(b.currency,'USD');i=invoice(b.product_name);return new Response(JSON.stringify(created(i)),{status:201});}return new Response(JSON.stringify(i));};
  const service=createPaymentService(paymentConfig(env),{fetchImpl,clock:()=>now});
  return {service,get invoice(){return i;},get calls(){return calls;},set down(v){down=v;}};
}
function confirm(i){Object.assign(i,{status:'confirmed',received_zatoshis:i.price_zatoshis,detected_txid:'a'.repeat(64),confirmed_at:new Date(now+1000).toISOString()});}
test('configuration rejects partial secrets, mainnet, credential URLs and insecure remote origins',()=>{
  assert.equal(paymentConfig({}),null);
  for(const changes of [{CIPHERPAY_API_KEY:''},{ZCASH_NETWORK:'mainnet'},{CIPHERPAY_API_URL:'http://gateway.example'},{APP_ORIGIN:'https://x.example/path'},{CIPHERPAY_API_URL:'https://user:password@gateway.example'},{STUDYPASS_ORDER_KEY:'short'}])assert.throws(()=>paymentConfig({...env,...changes}));
});
test('ZEC request amounts use exact integer zatoshis and reject exponent, overflow and fractional zatoshis',()=>{
  assert.equal(zecToZatoshis('0.00000001'),1);assert.equal(zecToZatoshis('0.00100000'),100000);
  for(const n of ['0','-1','1e-8','0.000000001','21000001','NaN',null])assert.throws(()=>zecToZatoshis(n));
});
test('order creation controls price, encrypts binding, preserves request and starts locked',async()=>{
  const f=fixture(),o=await f.service.create('focus-workbook');assert.equal(o.paymentVerified,false);assert.equal(o.canPay,true);assert.equal(o.status,'pending');assert.equal(o.network,'testnet');assert.equal(o.zcashUri,f.invoice.zcash_uri);assert.ok(!o.accessToken.includes(f.invoice.id));assert.equal(f.calls,2);
  await assert.rejects(()=>f.service.create('nclex'),/Unknown/);
});
test('a complete confirmed invoice unlocks only its bound order and remains idempotent',async()=>{
  const f=fixture(),o=await f.service.create('focus-workbook');confirm(f.invoice);
  for(let n=0;n<2;n++)assert.equal((await f.service.check(o.orderId,o.accessToken)).paymentVerified,true);
  await assert.rejects(()=>f.service.check('00000000-0000-0000-0000-000000000000',o.accessToken),/different order/);
});
test('token-only and relative checkout responses remain bound to the trusted origin and invoice',async()=>{
  for(const mode of ['token-only','relative','missing','bad-token','foreign-relative']){
    let i;
    const service=createPaymentService(paymentConfig(env),{clock:()=>now,fetchImpl:async(url,options)=>{
      if(options.method==='POST'){
        i=invoice(JSON.parse(options.body).product_name);const c=created(i);
        if(mode==='relative')c.checkout_url='/pay/'+i.id+'#checkout=fixture-token';
        else if(mode==='foreign-relative')c.checkout_url='//attacker.example/pay/'+i.id+'#checkout=fixture-token';
        else {delete c.checkout_url;if(mode!=='missing')c.checkout_token=mode==='bad-token'?'unsafe&other=value':'fixture-token';}
        return new Response(JSON.stringify(c));
      }
      return new Response(JSON.stringify(i));
    }});
    if(['missing','bad-token','foreign-relative'].includes(mode))await assert.rejects(()=>service.create('focus-workbook'));
    else {const o=await service.create('focus-workbook');assert.equal(o.checkoutUrl,'https://checkout.example/pay/'+i.id+'#checkout=fixture-token');assert.equal(o.paymentVerified,false);}
  }
});
test('tampered, unrelated-key and expired capabilities fail before a provider query',async()=>{
  const f=fixture(),o=await f.service.create('focus-workbook'),before=f.calls;
  await assert.rejects(()=>f.service.check(o.orderId,(o.accessToken[0]==='A'?'B':'A')+o.accessToken.slice(1)),/invalid or expired/);assert.equal(f.calls,before);
  const other=createPaymentService({...paymentConfig(env),key:randomBytes(32)},{clock:()=>now,fetchImpl:()=>{throw Error('must not query');}});
  await assert.rejects(()=>other.check(o.orderId,o.accessToken),/invalid or expired/);
  const expired=createPaymentService(paymentConfig(env),{clock:()=>now+31*86400000,fetchImpl:()=>{throw Error('must not query');}});
  await assert.rejects(()=>expired.check(o.orderId,o.accessToken),/invalid or expired/);
});
test('detected, pending, underpaid, cancelled, expired and refunded invoices never unlock',async()=>{
  for(const status of ['pending','detected','underpaid','cancelled','expired','refunded']){const f=fixture(),o=await f.service.create('focus-workbook');confirm(f.invoice);f.invoice.status=status;assert.equal((await f.service.check(o.orderId,o.accessToken)).paymentVerified,false,status);}
});
test('confirmed but underpaid, missing transaction, bad confirmation time and refunded records stay locked',async()=>{
  for(const changes of [{received_zatoshis:99999},{detected_txid:null},{detected_txid:'not-a-txid'},{confirmed_at:null},{confirmed_at:new Date(now-1000).toISOString()},{confirmed_at:new Date(now+120000).toISOString()},{refunded_at:new Date(now).toISOString()},{refund_txid:'b'.repeat(64)}]){const f=fixture(),o=await f.service.create('focus-workbook');confirm(f.invoice);Object.assign(f.invoice,changes);assert.equal((await f.service.check(o.orderId,o.accessToken)).paymentVerified,false);}
});
test('underpaid requests never invite a duplicate full payment',async()=>{
  const f=fixture(),o=await f.service.create('focus-workbook');confirm(f.invoice);f.invoice.received_zatoshis=99999;let r=await f.service.check(o.orderId,o.accessToken);assert.equal(r.status,'underpaid');assert.equal(r.canPay,false);assert.equal(r.paymentVerified,false);
  f.invoice.status='underpaid';assert.equal((await f.service.check(o.orderId,o.accessToken)).canPay,false);
});
test('expired pending requests are not payable or verified',async()=>{
  const f=fixture(),o=await f.service.create('focus-workbook');f.invoice.expires_at=new Date(now-1000).toISOString();const r=await f.service.check(o.orderId,o.accessToken);assert.equal(r.status,'expired');assert.equal(r.canPay,false);assert.equal(r.paymentVerified,false);
});
test('malformed, oversized, unauthenticated and redirecting gateway responses cannot issue an order',async()=>{
  for(const fetchImpl of [async()=>new Response('not JSON'),async()=>new Response('x'.repeat(61000)),async()=>new Response('{}',{status:401}),async()=>{throw Error('redirect');}]){
    await assert.rejects(()=>createPaymentService(paymentConfig(env),{fetchImpl,clock:()=>now}).create('focus-workbook'));
  }
});
test('wrong checkout origin, duplicate URI amounts and non-pending invoice reuse are rejected',async()=>{
  for(const type of ['origin','duplicate','reuse']){
    let i;const service=createPaymentService(paymentConfig(env),{clock:()=>now,fetchImpl:async(url,options)=>{if(options.method==='POST'){i=invoice(JSON.parse(options.body).product_name);if(type==='duplicate')i.zcash_uri+='&amount=0.00000001';if(type==='reuse')confirm(i);const c=created(i);if(type==='origin')c.checkout_url='https://attacker.example/pay/'+i.id+'#checkout=fixture';return new Response(JSON.stringify(c));}return new Response(JSON.stringify(i));}});
    await assert.rejects(()=>service.create('focus-workbook'),type);
  }
});
test('invoice rebinding, quote changes and wrong network fail closed',async()=>{
  for(const changes of [{id:'other'},{product_name:'other'},{amount:0.1},{currency:'EUR'},{memo_code:'OTHER'},{payment_address:'u1mainnet'},{price_zatoshis:90000},{zcash_uri:'javascript:alert(1)'},{created_at:new Date(now-5000).toISOString()},{received_zatoshis:0.1}]){const f=fixture(),o=await f.service.create('focus-workbook');confirm(f.invoice);Object.assign(f.invoice,changes);await assert.rejects(()=>f.service.check(o.orderId,o.accessToken));}
});
test('gateway outage cannot unlock or leak upstream exception details',async()=>{
  const f=fixture(),o=await f.service.create('focus-workbook');confirm(f.invoice);f.down=true;await assert.rejects(()=>f.service.check(o.orderId,o.accessToken),e=>e.status===503&&!e.message.includes('secret'));
});
test('overpayment can unlock; detection expiry extension preserves the original binding; later revocation relocks',async()=>{
  const f=fixture(),o=await f.service.create('focus-workbook');f.invoice.status='detected';f.invoice.expires_at=new Date(now+3600000).toISOString();assert.equal((await f.service.check(o.orderId,o.accessToken)).paymentVerified,false);confirm(f.invoice);f.invoice.received_zatoshis+=1000;assert.equal((await f.service.check(o.orderId,o.accessToken)).paymentVerified,true);f.invoice.status='refunded';assert.equal((await f.service.check(o.orderId,o.accessToken)).paymentVerified,false);
});
test('provider fee outputs are preserved and malformed requests are rejected before invoice issue',async()=>{
  for(const invalid of [false,true]){
    let i;const service=createPaymentService(paymentConfig(env),{clock:()=>now,fetchImpl:async(url,options)=>{if(options.method==='POST'){i=invoice(JSON.parse(options.body).product_name);i.zcash_uri='zcash:?address='+i.payment_address+'&amount=0.00100000&memo='+Buffer.from(i.memo_code).toString('base64url')+'&address.1='+(invalid?'u1mainnet':'utest1qqqqqqqqqq')+'&amount.1=0.00001000';return new Response(JSON.stringify(created(i)));}return new Response(JSON.stringify(i));}});
    if(invalid)await assert.rejects(()=>service.create('focus-workbook'));else{const o=await service.create('focus-workbook');assert.ok(o.zcashUri.includes('address.1='));}
  }
});
test('actual HTTP app keeps resources private and rechecks an HTTP stub gateway before fulfillment',async(t)=>{
  let i,requests=0,clockNow=now;
  const gateway=createServer(async(req,res)=>{requests++;assert.equal(req.headers.authorization,'Bearer '+env.CIPHERPAY_API_KEY);let text='';for await(const chunk of req)text+=chunk;if(req.method==='POST'){const b=JSON.parse(text);assert.equal(b.amount,1);i=invoice(b.product_name);res.end(JSON.stringify(created(i)));}else res.end(JSON.stringify(i));});gateway.listen(0,'127.0.0.1');await once(gateway,'listening');t.after(()=>gateway.close());
  const configEnv={...env,CIPHERPAY_API_URL:'http://127.0.0.1:'+gateway.address().port},app=createApp({env:configEnv,clock:()=>clockNow});app.listen(0,'127.0.0.1');await once(app,'listening');t.after(()=>app.close());const base='http://127.0.0.1:'+app.address().port;
  const make=(data,origin=env.APP_ORIGIN)=>fetch(base+'/api/orders',{method:'POST',headers:{'content-type':'application/json',origin},body:JSON.stringify(data)});
  assert.equal((await make({productId:'focus-workbook'},'https://attacker.example')).status,403);
  assert.equal((await make({productId:'focus-workbook',amount:0})).status,400);assert.equal(requests,0);
  const response=await make({productId:'focus-workbook'});assert.equal(response.status,201);const o=await response.json(),path='/api/orders/'+o.orderId,h={authorization:'Bearer '+o.accessToken};
  assert.equal((await fetch(base+'/resources/focus-workbook.md')).status,404);assert.equal((await fetch(base+'/.env')).status,404);assert.equal((await fetch(base+'/payments.mjs')).status,404);
  assert.equal((await fetch(base+path+'/resource')).status,401);assert.equal((await fetch(base+path+'/resource',{headers:h})).status,402);
  clockNow+=2000;confirm(i);const resource=await fetch(base+path+'/resource',{headers:h});assert.equal(resource.status,200);assert.match(resource.headers.get('content-disposition'),/attachment/);assert.match(await resource.text(),/Seven-session plan/);
  const receipt=await (await fetch(base+path+'/receipt',{headers:h})).json();assert.equal(receipt.paymentVerified,true);assert.equal(receipt.testnet,true);assert.equal(receipt.realMoney,false);assert.ok(!JSON.stringify(receipt).includes(env.CIPHERPAY_API_KEY));
  clockNow+=2000;i.status='refunded';assert.equal((await fetch(base+path+'/resource',{headers:h})).status,402);
});
test('unconfigured app exposes no payment creation and keeps free learning available',async(t)=>{
  const app=createApp({env:{}});app.listen(0,'127.0.0.1');await once(app,'listening');t.after(()=>app.close());const base='http://127.0.0.1:'+app.address().port;
  assert.equal((await (await fetch(base+'/api/payments/config')).json()).enabled,false);assert.equal((await fetch(base+'/api/orders',{method:'POST'})).status,503);assert.equal((await fetch(base+'/')).status,200);
});
