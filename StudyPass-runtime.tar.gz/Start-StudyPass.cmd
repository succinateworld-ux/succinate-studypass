@echo off
cd /d "%~dp0"
title Succinate StudyPass
node start-windows.mjs
if errorlevel 1 pause
