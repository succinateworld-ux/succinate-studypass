import {randomBytes, randomUUID, createCipheriv, createDecipheriv} from 'node:crypto';

export const PAYMENT_PRODUCT = Object.freeze({id:'focus-workbook',name:'StudyPass Focus Workbook',amount:1,currency:'USD'});
const MAX_ZAT = 21000000 * 100000000;
export class PaymentError extends Error {
  constructor(message,status=502){super(message);this.status=status;}
}
function requireThat(condition,message='Payment provider returned an invalid invoice.'){if(!condition)throw new PaymentError(message);}
function safeString(v,max){return typeof v==='string'&&v.length>0&&v.length<=max&&!/[\u0000-\u001f]/.test(v);}
export function zecToZatoshis(value){
  const s=String(value);
  if(!/^(0|[1-9]\d{0,7})(\.\d{1,8})?$/.test(s))throw new PaymentError('Invalid ZEC amount.');
  const [whole,fraction='']=s.split('.');const n=Number(BigInt(whole)*100000000n+BigInt(fraction.padEnd(8,'0')));
  requireThat(Number.isSafeInteger(n)&&n>0&&n<=MAX_ZAT);return n;
}
function endpoint(value,loopback=false){
  let u;try{u=new URL(value);}catch{throw new Error('Invalid payment service URL.');}
  if(u.username||u.password||u.search||u.hash||u.pathname!=='/'||(u.protocol!=='https:'&&!(loopback&&u.protocol==='http:'&&['127.0.0.1','localhost','[::1]'].includes(u.hostname))))throw new Error('Payment service URL must be an HTTPS origin (loopback HTTP is allowed for development).');
  return u.origin;
}
export function paymentConfig(env=process.env){
  const fields=['CIPHERPAY_API_URL','CIPHERPAY_CHECKOUT_ORIGIN','CIPHERPAY_API_KEY','STUDYPASS_ORDER_KEY','APP_ORIGIN'];
  if(fields.every(k=>!env[k]))return null;
  if(fields.some(k=>!env[k]))throw new Error('Payment configuration is incomplete. Set all values in .env.example or leave all payment settings unset.');
  if(env.ZCASH_NETWORK!=='testnet')throw new Error('This release only permits Zcash testnet.');
  if(!/^[a-f\d]{64}$/i.test(env.STUDYPASS_ORDER_KEY))throw new Error('STUDYPASS_ORDER_KEY must be 32 random bytes encoded as 64 hex characters.');
  if(!/^cpay_[A-Za-z0-9_-]{8,240}$/.test(env.CIPHERPAY_API_KEY))throw new Error('Invalid CipherPay API key format.');
  return {apiOrigin:endpoint(env.CIPHERPAY_API_URL,true),checkoutOrigin:endpoint(env.CIPHERPAY_CHECKOUT_ORIGIN,true),appOrigin:endpoint(env.APP_ORIGIN,true),apiKey:env.CIPHERPAY_API_KEY,key:Buffer.from(env.STUDYPASS_ORDER_KEY,'hex'),network:'testnet'};
}
function protect(payload,key){
  const iv=randomBytes(12),cipher=createCipheriv('aes-256-gcm',key,iv);cipher.setAAD(Buffer.from('studypass-order-v1'));
  const encrypted=Buffer.concat([cipher.update(JSON.stringify(payload),'utf8'),cipher.final()]);
  return Buffer.concat([iv,cipher.getAuthTag(),encrypted]).toString('base64url');
}
function unprotect(token,key,now){
  try{
    if(typeof token!=='string'||token.length>18000||!/^[\w-]+$/.test(token))throw 0;
    const b=Buffer.from(token,'base64url');if(b.length<29)throw 0;
    const cipher=createDecipheriv('aes-256-gcm',key,b.subarray(0,12));cipher.setAAD(Buffer.from('studypass-order-v1'));cipher.setAuthTag(b.subarray(12,28));
    const p=JSON.parse(Buffer.concat([cipher.update(b.subarray(28)),cipher.final()]).toString('utf8'));
    if(p.v!==1||p.productId!==PAYMENT_PRODUCT.id||p.network!=='testnet'||!Number.isSafeInteger(p.until)||p.until<=now)throw 0;
    return p;
  }catch{throw new PaymentError('Order access is invalid or expired.',401);}
}
function inspectUri(uri,address,zat,memo){
  requireThat(safeString(uri,10000)&&uri.startsWith('zcash:'));
  let u;try{u=new URL(uri);}catch{throw new PaymentError('Invalid Zcash payment request.');}
  requireThat(!u.hash&&!u.host&&!u.username&&!u.password);
  const entries=[...u.searchParams.keys()];requireThat(new Set(entries).size===entries.length);
  const primary=u.pathname||u.searchParams.get('address');
  requireThat(primary===address&&!(u.pathname&&u.searchParams.has('address')));
  requireThat(zecToZatoshis(u.searchParams.get('amount'))===zat,'Payment request amount does not match the invoice.');
  requireThat(u.searchParams.get('memo')===Buffer.from(memo).toString('base64url'),'Payment request memo does not match the invoice.');
  // Preserve the provider's complete request, including any additional fee output.
  for(const [key,val] of u.searchParams){
    requireThat(/^(address|amount|memo)(\.[1-9]\d*)?$/.test(key));
    if(key.startsWith('address'))requireThat(/^utest1[023456789acdefghjklmnpqrstuvwxyz]+$/.test(val));
    if(key.startsWith('amount'))zecToZatoshis(val);
  }
  for(const key of entries.filter(k=>k.startsWith('address.'))){const suffix=key.slice(7);requireThat(u.searchParams.has('amount'+suffix));}
  for(const key of entries.filter(k=>/^(amount|memo)\./.test(k))){requireThat(u.searchParams.has('address'+key.slice(key.indexOf('.'))));}
}
function checkedInvoice(i,now){
  requireThat(i&&typeof i==='object'&&safeString(i.id,100)&&/^[\w-]+$/.test(i.id));
  requireThat(safeString(i.memo_code,80)&&safeString(i.product_name,200));
  requireThat(i.currency===PAYMENT_PRODUCT.currency&&i.amount===PAYMENT_PRODUCT.amount,'The gateway invoice price or currency does not match this workbook.');
  requireThat(safeString(i.payment_address,1000)&&/^utest1[023456789acdefghjklmnpqrstuvwxyz]+$/.test(i.payment_address),'The gateway did not return a testnet Unified Address. No payment is allowed.');
  requireThat(Number.isSafeInteger(i.price_zatoshis)&&i.price_zatoshis>0&&i.price_zatoshis<=MAX_ZAT);
  requireThat(Number.isSafeInteger(i.received_zatoshis)&&i.received_zatoshis>=0&&i.received_zatoshis<=MAX_ZAT);
  requireThat(['pending','detected','confirmed','underpaid','expired','cancelled','refunded'].includes(i.status));
  requireThat(Number.isFinite(Date.parse(i.created_at))&&Number.isFinite(Date.parse(i.expires_at))&&Date.parse(i.created_at)<=now+60000);
  inspectUri(i.zcash_uri,i.payment_address,i.price_zatoshis,i.memo_code);
  return i;
}
function binding(i){return {id:i.id,product_name:i.product_name,amount:i.amount,currency:i.currency,memo_code:i.memo_code,payment_address:i.payment_address,price_zatoshis:i.price_zatoshis,zcash_uri:i.zcash_uri,created_at:i.created_at};}
function sameBinding(a,b){return Object.keys(a).every(k=>a[k]===b[k]);}
export function createPaymentService(config,{fetchImpl=fetch,clock=Date.now}={}){
  async function request(path,body){
    let r;
    try{r=await fetchImpl(config.apiOrigin+path,{method:body?'POST':'GET',headers:{'authorization':'Bearer '+config.apiKey,'accept':'application/json',...(body?{'content-type':'application/json'}:{})},body:body?JSON.stringify(body):undefined,signal:AbortSignal.timeout(12000),redirect:'error',cache:'no-store'});}catch{throw new PaymentError('The payment service is unavailable. Your resource remains locked.',503);}
    if(!r.ok){console.error('CipherPay request rejected',{operation:body?'create invoice':'read invoice',status:r.status});throw new PaymentError([401,403].includes(r.status)?'The payment provider did not authorize this merchant. Access remains locked.':'The payment service could not verify this request.',503);}
    let raw='';
    try{for await(const chunk of r.body){raw+=Buffer.from(chunk).toString('utf8');if(Buffer.byteLength(raw)>60000)throw new Error('oversized');}}catch{throw new PaymentError('Invalid payment response.');}
    try{return JSON.parse(raw);}catch{throw new PaymentError('Invalid payment response.');}
  }
  async function getInvoice(id){return checkedInvoice(await request('/api/invoices/'+encodeURIComponent(id)),clock());}
  function view(i,orderId,checkoutUrl){
    const paid=i.status==='confirmed'&&i.received_zatoshis>=i.price_zatoshis&&/^[a-f\d]{64}$/i.test(i.detected_txid||'')&&Number.isFinite(Date.parse(i.confirmed_at))&&Date.parse(i.confirmed_at)<=clock()+60000&&Date.parse(i.confirmed_at)>=Date.parse(i.created_at)&&!i.refunded_at&&!i.refund_txid;
    let status=i.status;
    if(i.status==='confirmed'&&!paid)status=i.received_zatoshis<i.price_zatoshis?'underpaid':'unverified';
    if(i.status==='pending'&&Date.parse(i.expires_at)<=clock())status='expired';
    return {orderId,invoiceId:i.id,productId:PAYMENT_PRODUCT.id,productName:PAYMENT_PRODUCT.name,network:'testnet',status,paymentVerified:paid,canPay:i.status==='pending'&&i.received_zatoshis===0&&Date.parse(i.expires_at)>clock(),expectedZatoshis:i.price_zatoshis,receivedZatoshis:i.received_zatoshis,paymentAddress:i.payment_address,zcashUri:i.zcash_uri,memo:i.memo_code,expiresAt:i.expires_at,checkoutUrl,txid:paid?i.detected_txid:null,confirmedAt:paid?i.confirmed_at:null};
  }
  return {
    async create(productId){
      if(productId!==PAYMENT_PRODUCT.id)throw new PaymentError('Unknown study resource.',400);
      const now=clock(),orderId=randomUUID(),name=PAYMENT_PRODUCT.name+' / '+orderId;
      const c=await request('/api/invoices',{product_name:name,amount:PAYMENT_PRODUCT.amount,currency:PAYMENT_PRODUCT.currency});
      requireThat(safeString(c.invoice_id,100)&&/^[\w-]+$/.test(c.invoice_id));
      const i=await getInvoice(c.invoice_id);
      requireThat(i.product_name===name&&i.status==='pending'&&i.received_zatoshis===0&&Date.parse(i.expires_at)>now&&Date.parse(i.created_at)>=now-60000);
      requireThat(c.memo_code===i.memo_code&&c.payment_address===i.payment_address&&c.zcash_uri===i.zcash_uri&&c.amount===i.amount&&c.currency===i.currency);
      // Older deployments return the documented checkout token without a URL.
      // Construct that URL only from our trusted origin and the rechecked invoice.
      let checkout;
      if(c.checkout_url==null){
        requireThat(safeString(c.checkout_token,2000)&&/^[\w-]+$/.test(c.checkout_token),'No valid hosted checkout token was supplied.');
        checkout=new URL('/pay/'+i.id+'#checkout='+c.checkout_token,config.checkoutOrigin);
      }else{
        try{checkout=new URL(c.checkout_url,config.checkoutOrigin);}catch{throw new PaymentError('No valid hosted checkout was supplied.');}
      }
      requireThat(checkout.origin===config.checkoutOrigin&&checkout.pathname==='/pay/'+i.id&&!checkout.search&&/^#checkout=[\w-]+$/.test(checkout.hash));
      const token=protect({v:1,orderId,productId,network:'testnet',quote:binding(i),checkoutUrl:checkout.href,until:now+30*86400000},config.key);
      return {...view(i,orderId,checkout.href),accessToken:token};
    },
    async check(orderId,token){
      const p=unprotect(token,config.key,clock());
      if(p.orderId!==orderId)throw new PaymentError('This key belongs to a different order.',403);
      const i=await getInvoice(p.quote.id);requireThat(sameBinding(p.quote,binding(i)),'The invoice changed. Access remains locked; contact the merchant.');
      return view(i,p.orderId,p.checkoutUrl);
    }
  };
}
