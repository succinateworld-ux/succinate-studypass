import {createServer} from 'node:http';
import {readFile} from 'node:fs/promises';
import {existsSync} from 'node:fs';
import {pathToFileURL} from 'node:url';
import {createHash} from 'node:crypto';
import {paymentConfig,createPaymentService,PAYMENT_PRODUCT,PaymentError} from './payments.mjs';

const routes=new Map([['/','index.html'],['/index.html','index.html'],...['styles.css','motion.css','learning.css','payments.css','motion.mjs','app.mjs','model.mjs','learning-data.mjs','learning-state.mjs','learning-app.mjs','metrics.mjs','payment-client.mjs'].map(f=>['/'+f,f])]);
const headers={'cache-control':'no-store','x-content-type-options':'nosniff','referrer-policy':'no-referrer','content-security-policy':"default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self'; object-src 'none'; base-uri 'none'; frame-ancestors 'none'; form-action 'self'",'permissions-policy':'camera=(), microphone=(), geolocation=()'};
function json(res,status,data){res.writeHead(status,{...headers,'content-type':'application/json; charset=utf-8'});res.end(JSON.stringify(data));}
async function body(req){
  let text='';for await(const chunk of req){text+=chunk.toString('utf8');if(Buffer.byteLength(text)>1024)throw new PaymentError('Request is too large.',413);}
  try{return JSON.parse(text);}catch{throw new PaymentError('Invalid JSON request.',400);}
}
export function createApp({env=process.env,fetchImpl=fetch,clock=Date.now}={}){
  const config=paymentConfig(env),service=config?createPaymentService(config,{fetchImpl,clock}):null;
  let creates=[];const checks=new Map();
  return createServer(async(req,res)=>{
    try{
      const url=new URL(req.url,'http://localhost'),path=url.pathname;
      if(path.startsWith('/api/')){
        if(path==='/api/payments/config'&&req.method==='GET')return json(res,200,{enabled:!!service,network:'testnet',provider:'CipherPay',product:PAYMENT_PRODUCT});
        if(!service)throw new PaymentError('Payments are not configured on this server. Free learning remains available.',503);
        if(req.method==='POST'&&path==='/api/orders'){
          if(req.headers.origin!==config.appOrigin||req.headers['sec-fetch-site']==='cross-site')throw new PaymentError('This request must come from the StudyPass checkout.',403);
          if(!/^application\/json(?:;|$)/i.test(req.headers['content-type']||''))throw new PaymentError('Use a JSON request.',415);
          const b=await body(req);if(!b||typeof b!=='object'||Array.isArray(b)||Object.keys(b).some(k=>k!=='productId'))throw new PaymentError('Only a catalog product may be requested. Prices are set by the server.',400);
          const now=clock();creates=creates.filter(t=>t>now-600000);if(creates.length>=10)throw new PaymentError('Checkout is busy. Please try again in ten minutes.',429);creates.push(now);
          return json(res,201,await service.create(b.productId));
        }
        const m=/^\/api\/orders\/([a-f\d-]{36})(\/resource|\/receipt)?$/.exec(path);
        if(req.method==='GET'&&m){
          const match=/^Bearer ([\w-]{1,18000})$/.exec(req.headers.authorization||'');if(!match)throw new PaymentError('An order access key is required.',401);
          const token=match[1],key=createHash('sha256').update(token+(m[2]||'/status')).digest('hex'),now=clock();
          for(const [k,t] of checks)if(t<=now-60000)checks.delete(k);
          if((checks.get(key)||0)>now-1500)throw new PaymentError('Please wait two seconds before checking again.',429);
          if(checks.size>=4096)throw new PaymentError('Checkout is busy. Please retry shortly.',429);
          checks.set(key,now);
          const order=await service.check(m[1],token);
          if(m[2]){
            if(!order.paymentVerified)throw new PaymentError('A fully paid, confirmed invoice is required. Access remains locked.',402);
            if(m[2]==='/receipt')return json(res,200,{...order,checkoutUrl:undefined,zcashUri:undefined,paymentAddress:undefined,memo:undefined,provider:'CipherPay',testnet:true,realMoney:false,verifiedBy:'server recheck of gateway invoice',notice:'Testnet transaction receipt. Test coins have no monetary value. This is not an independently verified mainnet settlement.'});
            const data=await readFile(new URL('./resources/focus-workbook.md',import.meta.url));res.writeHead(200,{...headers,'content-type':'text/markdown; charset=utf-8','content-disposition':'attachment; filename="Succinate-Focus-Workbook.md"'});return res.end(data);
          }
          return json(res,200,order);
        }
        throw new PaymentError('Endpoint or method not supported.',404);
      }
      if(!['GET','HEAD'].includes(req.method)){res.writeHead(405,headers);return res.end();}
      const file=routes.get(path);if(!file){res.writeHead(404,headers);return res.end('Not found');}
      const data=await readFile(new URL('./dist/'+file,import.meta.url)),mime=file.endsWith('.mjs')?'text/javascript':file.endsWith('.css')?'text/css':'text/html';
      res.writeHead(200,{...headers,'content-type':mime+'; charset=utf-8'});res.end(req.method==='HEAD'?undefined:data);
    }catch(error){
      if(res.headersSent){res.destroy();return;}
      json(res,error instanceof PaymentError?error.status:500,{error:error instanceof PaymentError?error.message:'The server could not complete this request. Access remains locked.'});
    }
  });
}
if(process.argv[1]&&import.meta.url===pathToFileURL(process.argv[1]).href){
  if(existsSync(new URL('./.env',import.meta.url)))process.loadEnvFile(new URL('./.env',import.meta.url));
  const port=Number(process.env.PORT||4180),host=process.env.HOST||'127.0.0.1';
  createApp().listen(port,host,()=>console.log(`StudyPass: http://${host}:${port}`));
}
