import {existsSync, mkdirSync, writeFileSync} from 'node:fs';
import {spawn} from 'node:child_process';
import {createApp} from './server.mjs';

const root = new URL('./', import.meta.url);
if (!existsSync(new URL('.env', root))) {
  console.error('Local payment configuration is missing. Keep merchant credentials in .env.');
  process.exit(1);
}
process.loadEnvFile(new URL('.env', root));
const origin = new URL(process.env.APP_ORIGIN);
if (origin.protocol !== 'http:' || origin.hostname !== '127.0.0.1') {
  throw new Error('This launcher requires a local 127.0.0.1 APP_ORIGIN.');
}
const server = createApp();
server.on('error', error => {
  console.error(error.code === 'EADDRINUSE'
    ? 'StudyPass is already running on this port. Close its existing window before restarting.'
    : 'StudyPass could not start: ' + error.code);
  process.exitCode = 1;
});
server.listen(Number(origin.port), '127.0.0.1', async () => {
  console.log('StudyPass is running at ' + origin.origin);
  console.log('Keep this window open while using the app. Close it to stop the server.');
  const state = {startedAt: new Date().toISOString(), pid: process.pid, origin: origin.origin};
  try {
    const response = await fetch(process.env.CIPHERPAY_API_URL + '/api/invoices', {
      headers: {authorization: 'Bearer ' + process.env.CIPHERPAY_API_KEY},
      signal: AbortSignal.timeout(12000), redirect: 'error'
    });
    state.apiReachable = true;
    state.apiHttpStatus = response.status;
    console.log('CipherPay connection reached the server (HTTP ' + response.status + ').');
  } catch (error) {
    state.apiReachable = false;
    state.connectionError = error.cause?.code || error.name;
    console.log('CipherPay connection is unavailable. Checkout will remain locked.');
  }
  mkdirSync(new URL('.local/', root), {recursive: true});
  writeFileSync(new URL('.local/runtime-status.json', root), JSON.stringify(state, null, 2));
  spawn('rundll32.exe', ['url.dll,FileProtocolHandler', origin.origin], {
    windowsHide: true, stdio: 'ignore'
  }).unref();
});
