# Zcash payment integration

## Actual status

The local source now includes a CipherPay API adapter, server-controlled invoices, encrypted order capabilities, a testnet checkout UI, and protected workbook/receipt routes. The former simulated-unlock checkout has been removed from the new UI. The original free-learning features remain available.

**This integration has not yet been verified against a real CipherPay merchant account or an on-chain testnet transaction. It is not complete or mainnet-ready.** Automated tests use explicitly test-only stub invoices, not blockchain evidence. The original published submission described a simulation; do not announce a completed integration until the completion evidence below exists.

## Merchant setup

1. Prepare a dedicated Zcash testnet receiving wallet and a separate funded testnet payer wallet. Keep seed phrases and spending keys private. Choose a wallet that supports testnet and exporting its Unified Full Viewing Key; verify these capabilities in its current official documentation before installing or funding it.
2. In the official [CipherPay testnet service](https://testnet.cipherpay.app/en/docs), complete merchant setup yourself. The gateway needs your testnet UFVK to see incoming payments. A viewing key cannot spend, but it reveals payment information: sharing it with the gateway is a privacy decision. Never provide a seed phrase or spending key.
3. Obtain the testnet merchant API key, actual API origin, and hosted checkout origin from the service. The API origin has not been independently confirmed for this deployment; do not guess it from the website URL.
4. Copy `.env.example` to ignored `.env` locally, or set secrets in the server host's environment. Set all required values. Never enter keys into frontend code, a GitHub file, an issue, a URL, or chat.
5. Generate a 32-byte order encryption key using the command in `.env.example`. Preserve this secret across deployments. Changing it invalidates outstanding order keys. StudyPass needs no UFVK or spending key: only the gateway API key and its own encryption key.
6. Set `APP_ORIGIN` to the exact deployed HTTPS origin. Local development can use `http://127.0.0.1:4180`. `ZCASH_NETWORK` must be `testnet`; mainnet is deliberately rejected in this release.
7. Start the Node server with `npm start`. Confirm `/api/payments/config` reports `enabled: true`, then create an invoice through the app. This flag confirms configuration presence only; it does not prove provider connectivity or successful payment.

## Host requirements

GitHub Pages serves static files and cannot run this payment backend. Keep it as a free-learning/static preview; its checkout remains unavailable. Deploy the Node application to a server host with secrets, HTTPS, and outbound HTTPS access. Set `HOST=0.0.0.0` there; `PORT` comes from the host. No package dependencies or database are required in StudyPass. The gateway holds invoice records; encrypted, authenticated order keys carry the immutable order binding.

The included Render blueprint describes a free Node service. It is deployment preparation, not proof that a service exists. Free hosts may sleep and have resource limits. Do not enable real-money sales on this testnet release.

## How verification works

- The server accepts only the `focus-workbook` product. Its quote starts at $1 USD, converted by the gateway to test ZEC. Client-supplied prices are rejected.
- Each invoice is created with a unique server-generated order reference. The server reads it back and checks the product reference, currency, fiat amount, testnet address prefix, integer zatoshi quote, memo, URI, status, and fresh timestamps. It verifies the request's recipient, amount, and encoded memo; fee outputs are preserved.
- The returned 30-day order capability uses AES-256-GCM with an authenticated version identifier. It binds the order ID, product, network, provider invoice, quote, destination, memo, and creation time. Possession of this private key file grants the ability to request checks for that one order. It cannot change any quoted field.
- Every status, receipt, and resource request re-fetches the provider invoice. A changed binding, invalid token, unavailable provider, insufficient amount, missing transaction ID, invalid confirmation timestamp, or refund prevents fulfillment.
- Only `confirmed` with at least the full quoted integer amount, a transaction ID, a valid confirmation timestamp, and no refund indicators can fulfill. Mempool detection never fulfills. The gateway's underpayment tolerance is not used to grant access.
- A gateway can extend invoice expiry after detection. The original payment quote and address remain bound. Quote renewal or changed destination is rejected. A late confirmation is accepted only if the gateway still confirms that bound invoice; payer-side expiry is not itself blockchain proof.
- The app does not offer to resend a full payment after an underpayment. Merchant review is required. The original request must not be reused blindly.
- Polling uses the server; the frontend cannot set a paid status. No inbound webhook is needed. An unsigned webhook cannot grant access because no webhook route exists.
- Capability keys are stored in this tab's session storage and can be privately backed up/restored. They are not included in learning backups or metrics. Access expires after 30 days and also depends on provider invoice retention. No account-based recovery exists in this release.

The integration trusts the configured gateway's TLS API, scanner, network configuration, and confirmation policy. It does not run an independent Zcash node, validate Unified Address checksums itself, or independently detect chain reorganizations. A status revoked by the gateway relocks future requests, but a file already downloaded cannot be recalled. The open-source workbook is also present in this MIT repository for review, so server gating is a demonstrator rather than commercially exclusive content or DRM.

## Required completion evidence

Do not mark complete until all of these are recorded from the **deployed** server and real testnet wallets:

| Evidence | Current result |
| --- | --- |
| Merchant account configured and real provider API reached | Not verified |
| App creates a real bound testnet invoice | Not verified |
| Before payment, direct workbook request returns 402 | Tested with stub only |
| Payer wallet sends the complete request on Zcash testnet | Not performed |
| Actual transaction ID and block confirmation recorded | None |
| Detected/unconfirmed invoice stays locked | Tested with stub only |
| Fully paid confirmed invoice unlocks the real workbook | Tested with stub only |
| Receipt matches that invoice and transaction | Tested with stub only |
| Private order backup restores and verifies after server restart | Not verified against real provider |
| Wrong/modified capability cannot download | Automated test passes |
| Underpayment, cancellation, refund, and provider outage stay locked | Automated tests pass; live recovery not verified |
| Free lessons still work without a wallet | Existing automated checks pass; new UI review pending |
| Live demo, README, and recorded walkthrough match final implementation | Pending |

Record transaction evidence in a private review file first. Obtain consent before publishing wallet addresses, invoice identifiers, receipts, or a transaction that links payment details. Publicly claiming an on-chain result requires real evidence, not the fixture strings used in tests.

## Protocol and API references

- [Official CipherPay docs](https://testnet.cipherpay.app/en/docs)
- [Official invoice API handlers](https://github.com/atmospherelabs-dev/cipherpay-api/blob/main/src/api/invoices.rs)
- [Official invoice schemas](https://github.com/atmospherelabs-dev/cipherpay-api/blob/main/src/invoices/types.rs)
- [Official invoice creation and state transitions](https://github.com/atmospherelabs-dev/cipherpay-api/blob/main/src/invoices/mod.rs)

Contracts were inspected on November 20, 2026. Hosted API compatibility remains an end-to-end test requirement, not an assumption that the source and deployed provider are identical.
