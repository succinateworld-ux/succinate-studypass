# Hosted StudyPass backend

The live server is https://succinate-studypass.onrender.com.

On November 21, 2026, the deployment was created through Render's browser dashboard using the existing public GitHub repository. Render detected Docker, the $0/month plan was selected, and deployment succeeded. The live landing page was visually verified in Chrome.

Source deployment commit shown by Render: 1de1bcb. The root Dockerfile unpacks StudyPass-runtime.tar.gz into /app and runs the included checks before starting the server. That archive contains the v0.2 source, dist assets, original workbook, tests, docs, and MIT license. It excludes merchant credentials and wallet files. Extract it to inspect or run the actual hosted source; the older root static demo files are retained separately in the repository.

Payment configuration is not installed on Render yet. Approval was requested to store only the CipherPay Testnet API key and StudyPass order-encryption key as Render secret environment variables. The merchant dashboard token and webhook secret are not required by this polling integration and should stay local.

Required runtime values after consent:

- ZCASH_NETWORK=testnet
- APP_ORIGIN=https://succinate-studypass.onrender.com
- CIPHERPAY_API_URL=https://api.testnet.cipherpay.app
- CIPHERPAY_CHECKOUT_ORIGIN=https://testnet.cipherpay.app
- CIPHERPAY_API_KEY: merchant secret, never committed
- STUDYPASS_ORDER_KEY: preserve the local configured key, never committed

Payment creation, actual payer-to-merchant transaction, confirmation, workbook unlock, receipt, and order restoration still require live verification. The hosted landing page working is not evidence of successful payment integration.

The free Render instance can sleep when inactive, delaying a first request by 50 seconds or more, according to its dashboard.