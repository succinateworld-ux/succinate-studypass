# Dedicated StudyPass testnet wallet setup

Prepared November 20, 2026. Wallet creation and funding are not yet verified.

## Prepared download

- Official release: https://github.com/hhanh00/zkool2/releases/tag/zkool-v6.37.0
- Archive: `C:\Users\USER\Downloads\zkool-6.37.0+395.zip`
- Archive size: 105,111,571 bytes.
- SHA-256: `5d869d5abd285a47f5d7653f5eccbc25f579098d871f3b59fe6dbf0dbe36ea22`
- The full computed hash matched the official release's digest using browser Find (one match). This verifies that the local archive matches the publisher's release; it is not an independent code audit.
- Extracted application: `C:\Users\USER\Documents\StudyPass-Testnet-Wallet\Zkool-6.37.0\zkool.exe`
- The Windows executable is unsigned. Approval to launch is pending. No wallet or keys were created by this preparation.

## Create the wallet privately

1. Open the extracted `zkool.exe` after approving the application. Do not bypass a Windows or browser security warning; stop if one appears.
2. Read the wallet disclaimer yourself. Complete any device authentication yourself.
3. Open the Database Manager. The current official instructions describe the folder icon in Settings followed by restarting the app. Add a new database with the `+` control.
4. Name it `StudyPass Testnet` and explicitly choose **Testnet** in the Network dropdown. Mainnet is the default. The wallet name does not select its network, and the network cannot be changed after the database is created.
5. Create a new account named `StudyPass Merchant`. Make a private offline backup of its newly generated seed. Never paste the seed or spending key into chat, a website, source files, or the StudyPass app.
6. Create a separate account named `StudyPass Test Payer` and privately back up that account too. The payer and merchant need separate account keys so the end-to-end test reflects distinct payment participants.
7. Return to the normal account screen before resuming computer assistance. Verify the database is Testnet and syncing. The documented default testnet lightwallet server is `https://testnet.zec.rocks`; do not change it to a mainnet server.

The actual screens must be checked during setup; these steps follow the current official documentation and are not a claim that setup has completed.

## Funding and merchant setup

After creation, obtain the **payer's public testnet receiving address** from Receive. A public Unified testnet address starts `utest1`. Only this public address is needed to request test coins. A faucet never needs your seed, spending key, or viewing key. Test coins have no monetary value and must not be purchased as real ZEC.

For the merchant, CipherPay's testnet setup requires a testnet Unified Full Viewing Key (`uviewtest...`) and receiving address. Export the merchant account's full viewing key through the wallet's official interface; do not use its spending-key/seed backup screen. A viewing key reveals payment information, although it cannot spend. The wallet owner must deliberately authorize its disclosure to the gateway. Never use the payer's viewing key for merchant setup.

Do not paste any API key or wallet key into chat. Configure the merchant and server secrets privately, following [PAYMENTS.md](PAYMENTS.md). Hosted API compatibility remains unverified until a real invoice is created and paid.

## References

- https://hhanh00.github.io/zkool2/guide/start.html
- https://hhanh00.github.io/zkool2/recipe/database.html
- https://hhanh00.github.io/zkool2/recipe/net.html
- https://hhanh00.github.io/zkool2/guide/accounts.html
- https://hhanh00.github.io/zkool2/recipe/restore.html
- https://testnet.cipherpay.app/en/docs
- https://zechub.wiki/using-zcash/testnet

## Submission reaction check

The original StudyPass message in `@ZcashIN` showed **3 heart reactions** during this review. The surrounding messages and latest messages inspected contained member-join notices and another participant's entry; no direct organizer reply or eligibility acceptance was seen. This is a point-in-time observation, not a guarantee that no reply exists elsewhere or arrives later. No follow-up was posted and no reaction was added.

## 2026-11-20 merchant connection and funding

- Encrypted Testnet database `studypasstestnet2.db` reopened successfully. StudyPass Merchant and StudyPass Test Payer accounts were created; the user handled recovery phrases privately.
- Requested 1 TAZ from fauzec.com after the user completed its human check. Zkool synchronization showed the payer balance as 1.00000000 TAZ and one received transaction.
- User explicitly authorized sharing the merchant UFVK with CipherPay Testnet. Registered Succinate StudyPass and successfully signed into its Testnet dashboard.
- User authorized local credential storage. Credentials are in the local `.env`; `git check-ignore .env` confirmed exclusion. No keys belong in this document, screenshots distributed with the submission, or source archives.
- CipherPay's Sandbox & Testing guide identifies `https://api.testnet.cipherpay.app` as its Testnet API. Local server configured at `http://127.0.0.1:4182`; `/api/payments/config` reported enabled, Testnet, Focus Workbook USD 1. This flag only confirms configuration.
- A real local POST `/api/orders` returned HTTP 503. A credential-free connectivity probe established `connect EACCES` for the API host on port 443 in this execution environment. No invoice was successfully created, no payer-to-merchant purchase was made, and no workbook unlock was verified.
- Remaining: deploy the server somewhere with permitted outbound HTTPS, verify invoice creation, perform a real testnet payment, verify server-confirmed resource and receipt access, then publish updated source/demo and submission evidence. Public GitHub Pages is still the previous simulated version.
