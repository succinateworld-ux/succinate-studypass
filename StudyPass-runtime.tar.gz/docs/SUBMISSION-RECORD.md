# Submission record

On November 20, 2026, the StudyPass entry was posted to the Zcash India Telegram group, `@ZcashIN` (https://t.me/ZcashIN), following its pinned Build on Zcash announcement. The outgoing message displayed 11:17 AM and Telegram's sent check mark. This verifies sending, not organizer acceptance, eligibility approval, judging, or an award.

- Public MIT repository: https://github.com/succinateworld-ux/succinate-studypass
- Published demo: https://succinateworld-ux.github.io/succinate-studypass/
- Submitted write-up: https://github.com/succinateworld-ux/succinate-studypass/blob/main/docs/SUBMISSION.md
- GitHub Pages reported the site live; its published landing page and ungated free workspace were opened successfully in Chrome.
- All sixteen local automated tests passed. No new clinical review, mobile-device review, or blockchain payment test was performed.

The message explicitly described the payment flow as simulated, stated that no ZEC is sent or verified and no secure paid entitlements exist, and identified merchant-side invoice verification as future work. Expanded study packs were identified as concepts.

The pinned announcement states a November 27, 2026 deadline and accepts early-stage projects. It requests an MIT-licensed GitHub repository, README with description/how it works/run instructions, and supporting material posted in the Telegram group. No exact cutoff time was visible.

No demo video was submitted. The supporting material was the live app and written demo walkthrough. No transaction, payment, prize payout, or acceptance is claimed.

This record is local and was written after the public source upload; it is not part of the four published source commits.
